/**
 * Charts Barrel Export
 *
 * Re-exports dynamic chart components (Recharts with dynamic loading)
 */

export * from './dynamic-recharts';
