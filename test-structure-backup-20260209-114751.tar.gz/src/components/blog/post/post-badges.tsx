import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import type { Post } from "@/data/posts";
import { POST_CATEGORY_LABEL } from "@/lib/post-categories";
import { SEMANTIC_COLORS } from "@/lib/design-tokens";

interface PostBadgesProps {
  post: Post;
  size?: "default" | "sm";
  isLatestPost?: boolean;
  isHotPost?: boolean;
  showCategory?: boolean;
  showFeatured?: boolean;
}

/**
 * Display status badges for a blog post (Featured, Draft, Archived, Hot, New, etc.)
 * Badges are displayed inline to the right of the title text
 * Note: These badges are NOT links since they're rendered inside clickable cards
 */
export function PostBadges({
  post,
  size = "default",
  isLatestPost,
  isHotPost,
  showCategory = false,
  showFeatured = true,
}: PostBadgesProps) {
  const badges = [];

  // Featured badge - displayed first for prominence
  if (showFeatured && post.featured) {
    badges.push(
      <Badge
        key="featured"
        className={cn(
          size === "sm" ? "text-xs" : "",
          "pointer-events-none",
          SEMANTIC_COLORS.status.success
        )}
      >
        Featured
      </Badge>
    );
  }

  // Draft badge (development only)
  if (process.env.NODE_ENV === "development" && post.draft) {
    badges.push(
      <Badge
        key="draft"
        className={`${size === "sm" ? "text-xs" : ""} pointer-events-none`}
        variant="outline"
      >
        Draft
      </Badge>
    );
  }

  // Archived badge - dimmed
  if (post.archived) {
    badges.push(
      <Badge
        key="archived"
        variant="outline"
        className={`${size === "sm" ? "text-xs" : ""} pointer-events-none bg-muted/70 text-muted-foreground border-border/70`}
      >
        Archived
      </Badge>
    );
  }

  // New badge - for the latest published post (not archived or draft)
  if (isLatestPost && !post.archived && !post.draft) {
    badges.push(
      <Badge
        key="new"
        className={cn(
          size === "sm" ? "text-xs" : "",
          "pointer-events-none",
          SEMANTIC_COLORS.status.success
        )}
      >
        New
      </Badge>
    );
  }

  // Hot badge - for the post with the most views (not draft or archived)
  if (isHotPost && !post.archived && !post.draft) {
    badges.push(
      <Badge
        key="hot"
        className={cn(
          size === "sm" ? "text-xs" : "",
          "pointer-events-none",
          SEMANTIC_COLORS.status.error
        )}
      >
        Hot
      </Badge>
    );
  }

  // Category badge
  if (showCategory && post.category) {
    const categoryLabel = POST_CATEGORY_LABEL[post.category];

    // Only render if category label exists (prevents empty badges)
    if (categoryLabel) {
      badges.push(
        <Badge
          key="category"
          variant="outline"
          className={`${size === "sm" ? "text-xs" : ""} pointer-events-none`}
        >
          {categoryLabel}
        </Badge>
      );
    } else if (process.env.NODE_ENV === "development") {
      // Show warning badge in development for undefined categories
      badges.push(
        <Badge
          key="category-error"
          variant="outline"
          className={`${size === "sm" ? "text-xs" : ""} pointer-events-none bg-destructive/10 text-destructive border-destructive/50`}
        >
          Invalid Category: {post.category}
        </Badge>
      );
      console.warn(
        `[PostBadges] Category "${post.category}" not found in POST_CATEGORY_LABEL mapping.`,
        `Add it to src/lib/post-categories.ts`,
        `Post: ${post.title || post.id || "unknown"}`
      );
    }
  }

  if (badges.length === 0) {
    return null;
  }

  return <>{badges}</>;
}
